import requests
import json
import os
from datetime import datetime

CONFIG_FILE = ".moltbook_config.json"
BOUNTY_LOG = "moltbook_bounties.json"

def load_config():
    with open(CONFIG_FILE, 'r') as f:
        return json.load(f)

def check_moltbook():
    config = load_config()
    headers = {"Authorization": f"Bearer {config['api_key']}"}
    
    print(f"[{datetime.now()}] Initiating Moltbook Scan...")
    
    # 1. Check Home for Notifications/DMs
    home = requests.get(f"{config['base_url']}/home", headers=headers).json()
    unread = home.get('your_account', {}).get('unread_notification_count', 0)
    print(f"Unread Notifications: {unread}")

    # 2. Search for new Bounties/Tasks
    keywords = ["bounty", "task", "verify", "audit"]
    found_opportunities = []
    
    for k in keywords:
        search = requests.get(f"{config['base_url']}/search?q={k}&type=posts", headers=headers).json()
        if search.get('success'):
            for post in search.get('results', []):
                # Filter for posts created in the last 24 hours (approx)
                found_opportunities.append({
                    "id": post['id'],
                    "title": post['title'],
                    "author": post['author']['name'],
                    "submolt": post['submolt']['name'],
                    "url": f"https://www.moltbook.com/posts/{post['id']}"
                })

    # 3. Log findings
    if os.path.exists(BOUNTY_LOG):
        with open(BOUNTY_LOG, 'r') as f:
            existing = json.load(f)
    else:
        existing = []

    # Update with new unique items
    new_ids = {item['id'] for item in found_opportunities}
    existing_ids = {item['id'] for item in existing}
    
    updated = existing + [item for item in found_opportunities if item['id'] not in existing_ids]

    with open(BOUNTY_LOG, 'w') as f:
        json.dump(updated, f, indent=4)

    print(f"Scan complete. {len(found_opportunities)} opportunities tracked.")
    return found_opportunities

if __name__ == "__main__":
    check_moltbook()
